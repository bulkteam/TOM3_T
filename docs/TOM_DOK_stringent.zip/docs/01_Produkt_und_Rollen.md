# Kapitel 1 – Produkt, Rollen, Begriffe

## Ziel
TOM soll einen skalierbaren Prozess abbilden, der **mit minimalem Aufwand** bei Inside Sales startet und erst bei zunehmender Reife mehr Struktur/Technik verlangt.

Leitprinzip: **„Technischer Aufwand steigt mit der Bearbeitungsstufe“**

## Rollen & Verantwortlichkeiten

### Sales Ops
- Importiert Firmen (Quelle/Importbatch)
- Verantwortlich für **Angebotserstellung** nach Qualifizierung
- Bearbeitet Vorgänge aus einer **Team Queue** (unassigned) oder „claimed“ sie

### Inside Sales
- Bearbeitet importierte Firmen in einer **Queue**
- Telefoniert, recherchiert, dokumentiert Outcomes/Notizen
- Setzt Priorität (1–5 Sterne) und Wiedervorlagen
- Übergibt:
  - **Qualifizierte Bedarfe** an Sales Ops zur Angebotserstellung
  - **Unklare Datenfälle** an Sales Ops (Data Check), ohne Angebot

### (Später) Projektteam / AM
- Übernimmt nach Angebot/Beauftragung oder für komplexe Bündel
- Bündelt mehrere Vorgänge zu einem Projekt (kommt später)

## Fachliche Begriffe (klar getrennt)

### Lead / Aktion (leichtgewichtig)
- Frühphase (Akquise/Leadgen)
- Kann in „nichts“ enden (disqualify/duplicate/no contact)
- Benötigt: Prio, Wiedervorlage, Log (Timeline)
- **Keine** Aufgabenverwaltung (Tasks) im MVP

### Vorgang (mittel)
- Konkreter Bedarf / Angebotsanfrage / Arbeitsauftrag
- Hat ggf. Aufgaben, SLA, Angebotsstatus
- Owner typischerweise Sales Ops (Team Queue oder Claim)

### Projekt (schwer, später)
- Container über mehreren Vorgängen
- Teamzuordnung, Meilensteine, Reporting

## Übergabearten (wichtig)
Inside Sales kann zwei unterschiedliche Übergaben machen:

1. **QUOTE_REQUEST (Angebot anfordern)**
   - Aus Lead wird ein Vorgang
   - Geht an Sales Ops Team Queue „Angebote“

2. **DATA_CHECK (Daten unklar)**
   - Bleibt Lead, geht an Sales Ops Team Queue „Data Check“
   - Ziel: Daten anreichern/klären, dann zurück an Inside Sales
