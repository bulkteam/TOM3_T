# Kapitel 2 – Workflow (End-to-End)

## Phase 0: Sales Ops Import
1. Sales Ops importiert Firmen.
2. System legt je Firma an:
   - Organisation/Stammdaten (minimal)
   - **WorkItem** (type=LEAD, stage=NEW, source=IMPORT, batchId)
3. Optional: Flag „mögliche Dublette“ (Hinweis, kein Blocker).

Ergebnis: Inside Sales erhält eine **arbeitbare Queue**, nicht nur Rohdaten.

---

## Phase 1: Inside Sales – Funnel/Queue
Inside Sales arbeitet in Tabs (mit Zähler):
- **Neu** (stage NEW)
- **Fällig heute** (next_action_at ≤ heute oder null + unberührt)
- **In Arbeit** (owner=me)
- **Snoozed** (next_action_at > heute)
- **Qualifiziert** (kurz vor Übergabe; oft direkt handoff)
- **Geschlossen** (optional)

Default-Sortierung:
1) Sterne (5→1)  
2) next_action_at (früh zuerst, null „sofort“)  
3) last_touch_at (ältere zuerst)

---

## Phase 2: Inside Sales – Telefonmodus (Lead-Player)
Ziel: klick-für-klick, kaum Navigation.

Pro Lead:
1) **Anrufen** (sipgate Webphone)
2) CRM zeigt Status (ringing/connected/ended) + Timer (Polling)
3) Beim Ende öffnet automatisch **Disposition**
   - Outcome (erreicht / nicht erreicht / Rückruf / falsche Nummer / kein Bedarf / qualifiziert)
   - Notiz
   - Wiedervorlage Quickbuttons (heute 16:00 / morgen 10:00 / +3T / +1W)
4) **Save & Next** lädt sofort den nächsten Lead

Wichtig: Alles wird als **Timeline (Activity)** gespeichert – auch in der Akquisephase.

---

## Phase 3: Entscheidungen im Lead
### Snooze / Wiedervorlage
- Setzt next_action_at/type
- Lead verschwindet aus „Fällig heute“ bis zum Termin.

### Disqualify / Duplicate
- stage DISQUALIFIED oder DUPLICATE, status CLOSED
- kurzer Grund in Timeline (für Reporting/Qualität)

### Weiterbearbeiten
- stage IN_PROGRESS/SNOOZED
- Timeline dokumentiert die Schritte

---

## Phase 4: Übergaben (Inside Sales → Sales Ops)

### A) QUOTE_REQUEST (Qualifiziert → Angebot)
Inside Sales füllt Mini-Handover (3 Pflichtfelder):
1) Bedarf (1 Satz)
2) Ansprechpartner/Hint (oder „unbekannt“)
3) Next Step (z.B. Angebot erstellen)

System:
- type: LEAD → VORGANG
- stage: QUOTE_REQUESTED
- owner_team: sales_ops, owner_user_id: null (Team Queue)
- Timeline: HANDOFF pinned (Übergabeanker)

### B) DATA_CHECK (Unklare Daten → Datenklärung)
Zusätzlich zu Summary:
- Issue (was ist unklar?)
- Request (was soll Sales Ops klären?)

System:
- type bleibt LEAD
- stage: DATA_CHECK
- owner_team: sales_ops, owner_user_id: null
- Timeline: HANDOFF pinned

---

## Phase 5: Sales Ops – Team Queues
### Angebote (Team Queue)
- type=VORGANG, stage in (QUOTE_REQUESTED, QUOTING), owner_user_id=null
- optional „Claim“ durch Sales Ops User

### Data Check (Team Queue)
- type=LEAD, stage=DATA_CHECK, owner_user_id=null
- nach Klärung: zurück an Inside Sales (owner_team=inside_sales, stage=NEW/IN_PROGRESS)
- Timeline enthält „Data Check erledigt“ inkl. ergänzt/gefunden

---

## Durchgehende Historie (ab Tag 1)
Unabhängig von Stage/Typ gilt:
- Alle Gespräche/Notizen/Outcomes/Wiedervorlagen/Übergaben landen in der Timeline
- Bei Handoff bleibt Historie vollständig sichtbar (kein Kopieren)
