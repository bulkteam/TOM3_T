# Kapitel 3 – Architektur & Datenmodell

## Architekturüberblick
- **Frontend:** SPA (Queue + Dialer + Sales Ops Queues)
- **Backend:** PHP JSON-API, Session-Cookies, CSRF
- **DB:** MariaDB (Source of Truth)
- **Telephony:** sipgate Webphone, Call-Start via Backend, Status via Polling

## Kernobjekte

### WorkItem (Root / Thread)
Ein WorkItem ist der durchgehende „Thread“ von Import bis Angebot:
- type: LEAD | VORGANG | (später) PROJEKT
- stage: abhängig von type
- owner_team + owner_user_id
- stars (1–5), next_action_at/type
- last_touch_at + touch_count
- source_type + source_batch_id

Warum so?
- Ein Objekt, eine Historie, klare Übergabepunkte.

### Timeline / Activity
- fachlicher Log (Human): Calls, Notes, Outcomes, Snooze, Handoff
- enthält strukturierte `details` (JSON), um Reportings zu ermöglichen
- wichtige Einträge können „pinned“ werden (insb. HANDOFF)

### Audit Trail
- technische Feldänderungen (wer hat was geändert?)
- optional sichtbar, aber vollständig

## Stages (MVP)
### LEAD
- NEW, IN_PROGRESS, SNOOZED, QUALIFIED, DISQUALIFIED, DUPLICATE, DATA_CHECK

### VORGANG
- QUOTE_REQUESTED, QUOTING, OFFER_SENT, WON, LOST

## Queues (Filterlogik)
### Inside Sales
- zeigt primär owner_team=inside_sales + type=LEAD + status=OPEN
- Tabs basieren auf stage/next_action_at

### Sales Ops „Angebote“
- type=VORGANG
- stage in (QUOTE_REQUESTED, QUOTING)
- owner_team=sales_ops
- owner_user_id is null (Team Queue)

### Sales Ops „Data Check“
- type=LEAD
- stage=DATA_CHECK
- owner_team=sales_ops
- owner_user_id is null (Team Queue)

## Telephony (sipgate) – Polling Ansatz
- Frontend startet Call über Backend (Tokens bleiben serverseitig)
- Backend erzeugt Activity TOUCH_CALL „pending“
- Frontend pollt Backend-Status (Backend cached/pollt sipgate)
- Bei end: Disposition wird erfasst und Activity finalisiert

Empfehlung: Statuscache via `telephony_call` Tabelle (callRef, state, timestamps, duration).

## Minimal-UI Regeln (für Geschwindigkeit)
- Queue: Tabs + kompakte Liste + Inline Sterne + Snooze
- Dialer: Outcome-Bar + Disposition Sheet + Save&Next
- Timeline: immer sichtbar (Human), Audit optional
