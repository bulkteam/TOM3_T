# Kapitel 4 – Implementierungsplan (Häppchenweise) & API/JSON-Kontrakte

## Vorgehen (4 Inkremente)
1) Fundament: WorkItem + Timeline + Queue (ohne Telephony)  
2) Dialer UI: Lead-Player + Disposition (ohne sipgate)  
3) Handoff: QUOTE_REQUEST + DATA_CHECK + Sales Ops Queues  
4) sipgate Integration: Call-Start + Polling + Call-Finalize

Die Checklisten dafür stehen in der Projektkommunikation (siehe Chat-Plan); diese Datei enthält die zentralen Kontrakte.

---

## API – zentrale Endpunkte (MVP)
### Auth
- GET /api/auth/me
- GET /api/auth/csrf

### WorkItems
- GET /api/work-items (Queue + counts)
- GET /api/work-items/:id (Detail)
- PATCH /api/work-items/:id (stars, snooze, stage, owner)
- GET /api/work-items/:id/timeline
- POST /api/work-items/:id/activities (NOTE / NEXT_ACTION_SET / STATUS_CHANGED)

### Handoff (vereinheitlicht)
- POST /api/work-items/:id/handoff
  - handoffType = QUOTE_REQUEST | DATA_CHECK

### Telephony (sipgate, Polling)
- POST /api/telephony/calls
- GET /api/telephony/calls/:callRef
- POST /api/activities/:activityId/finalize

---

## JSON-Kontrakte (Kurzform)
Hinweis: Vollständige JSON Schemas siehe Chat-Export; hier die „Developer Contracts“ als Beispiele.

### Handoff: DATA_CHECK – Request
```json
{
  "handoffType": "DATA_CHECK",
  "stars": 4,
  "summary": {
    "needSummary": "Akquise-Lead, Datenlage unklar – noch kein Bedarf bestätigt.",
    "contactHint": "Zentrale/Empfang; Ansprechpartner unbekannt",
    "nextStep": "Bitte Kontaktdaten validieren, dann zurück an Inside Sales"
  },
  "dataCheck": {
    "issue": "Telefon ungültig, Website unklar, mögliche Dublette.",
    "request": "Bitte Website/Telefon recherchieren und Dublette prüfen.",
    "links": ["https://www.handelsregister.de/"]
  }
}
```

### Handoff: QUOTE_REQUEST – Request
```json
{
  "handoffType": "QUOTE_REQUEST",
  "stars": 5,
  "summary": {
    "needSummary": "Angebot für Maschine X inkl. Montage, Bedarf bestätigt.",
    "contactHint": "Herr Müller (Einkauf), mueller@…, +49…",
    "nextStep": "Angebot erstellen und senden; Lieferzeit klären"
  }
}
```

### Telephony: Start Call – Response
```json
{ "callRef": "crmcall_abc123", "activityId": 987 }
```

### Telephony: Poll Status – Response
```json
{
  "callRef": "crmcall_abc123",
  "state": "connected",
  "durationSec": 42,
  "startedAt": "2026-01-04T11:00:00+01:00",
  "connectedAt": "2026-01-04T11:00:05+01:00",
  "endedAt": null,
  "errorMessage": null
}
```

---

## Definition of Done (Gesamtworkflow)
- Import erzeugt Leads (WorkItems type=LEAD)
- Inside Sales kann Leads in Queue sehen und im Dialer abarbeiten (Outcomes, Notizen, Snooze)
- Handoff:
  - QUOTE_REQUEST erzeugt Vorgang in Sales Ops Angebots-Queue
  - DATA_CHECK erzeugt Lead in Sales Ops Data-Check-Queue
- Timeline ist durchgehend und beim Handoff vollständig sichtbar
- sipgate Call-Start + Polling + Disposition funktioniert im Dialer
