# TOM – Produktdokumentation (stringent)

Diese Dokumentation bündelt den gewünschten **Inside-Sales → Sales Ops** Prozess (inkl. sipgate Webphone) in wenigen, zusammenhängenden Kapiteln.
Detail-Notizen/Analysen aus dem bisherigen Doku-Stand liegen weiterhin im Anhang unter `docs/appendix/legacy/`.

## Schnellstart (Lesereihenfolge)

1. **Kapitel 1:** Produkt, Rollen, Begriffe  
   → `docs/01_Produkt_und_Rollen.md`
2. **Kapitel 2:** End-to-End Workflow inkl. Übergaben (Inside Sales, Sales Ops)  
   → `docs/02_Workflow.md`
3. **Kapitel 3:** Architektur, Datenmodell, Timeline (Activity/Audit), Queues  
   → `docs/03_Architektur_und_Datenmodell.md`
4. **Kapitel 4:** Implementierungsplan in Häppchen (Kapitel 1–4) + API/JSON-Kontrakte  
   → `docs/04_Implementierung_Roadmap.md`

## Verzeichnisstruktur

```
docs/
  README.md
  01_Produkt_und_Rollen.md
  02_Workflow.md
  03_Architektur_und_Datenmodell.md
  04_Implementierung_Roadmap.md
  appendix/
    README.md
    legacy/   (bestehende Einzeldokumente, unverändert)
```

## Stand
- Datum: 2026-01-04
- Fokus: Inside Sales Queue + Telefonmodus (sipgate Webphone, Polling) + Handoff an Sales Ops (Team Queue)
