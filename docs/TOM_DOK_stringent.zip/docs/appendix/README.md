# Anhang: Legacy-Dokumente

In `legacy/` liegen die bestehenden Einzeldokumente (Analysen, Implementierungsnotizen, Konzepte).
Sie bleiben unverändert, damit nichts verloren geht.

## Empfehlung zur Nutzung
- Für das „Warum/Was“ zuerst die Kapitel 1–4 lesen.
- Für Detailfragen (z.B. Import-Edge-Cases, Audit-Trail-Vereinheitlichung, ClamAV) in `legacy/` nachschlagen.

## Themen-Finder (Quick Links)
- Import: Dateien mit Prefix `CRM_IMPORT_...`
- Activity/Audit: `ACTIVITY-LOG-...`, `AUDIT-TRAIL-...`
- Security: `SECURITY-...`
- UI/Setup: `UI.md`, `SETUP.md`
- ClamAV: `CLAMAV-...`
