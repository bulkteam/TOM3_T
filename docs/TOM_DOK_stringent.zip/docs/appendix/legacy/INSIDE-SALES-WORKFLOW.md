# Inside Sales Workflow - Dokumentation

**Stand:** 2026-01-05  
**Version:** 1.0  
**Status:** Implementiert

---

## Übersicht

Der Inside Sales Workflow ist ein vollständiger Lead-Management-Prozess, der von der Lead-Qualifizierung bis zur Übergabe an Sales Ops reicht. Der Workflow basiert auf dem Konzept eines **WorkItems**, das sich von einem LEAD zu einem VORGANG entwickelt.

### Kernkonzepte

1. **WorkItem** (`case_item`): Zentrales, persistentes Objekt, das sich von LEAD → VORGANG → PROJEKT entwickelt
2. **Activity Timeline** (`work_item_timeline`): Dedizierte Historie für Sales-Aktivitäten (getrennt vom System-Activity-Log)
3. **Progressive Komplexität**: Komplexität (Tasks, Projekt-Bündelung) wird erst eingeführt, wenn nötig (z.B. bei LEAD → VORGANG)
4. **Klare Rollentrennung**: Inside Sales (Lead-Generierung, Qualifizierung) vs. Sales Ops (Angebotserstellung, Prozess-Management)

---

## Architektur

### Datenbank-Schema

#### `case_item` (erweitert)

Zusätzliche Felder für Inside Sales:

```sql
stage VARCHAR(50)              -- NEW, IN_PROGRESS, SNOOZED, QUALIFIED, DISQUALIFIED, DUPLICATE, DATA_CHECK
priority_stars TINYINT         -- 1-5 Sterne
next_action_at DATETIME        -- Wiedervorlage
next_action_type VARCHAR(50)   -- call, email, etc.
last_touch_at DATETIME         -- Letzte Bearbeitung
touch_count INT                -- Anzahl Bearbeitungen
source_type VARCHAR(50)        -- IMPORT, MANUAL
source_batch_uuid CHAR(36)     -- Import-Batch-Referenz
owner_team VARCHAR(50)         -- inside_sales, sales_ops
```

#### `work_item_timeline` (neu)

Dedizierte Timeline für Sales-Aktivitäten:

```sql
timeline_id BIGINT PRIMARY KEY
work_item_uuid CHAR(36)        -- = case_uuid
activity_type VARCHAR(50)      -- NOTE, NEXT_ACTION_SET, STATUS_CHANGED, HANDOFF, TOUCH_CALL
created_by VARCHAR(50)         -- USER | SYSTEM
created_by_user_id VARCHAR(255)
occurred_at DATETIME
summary TEXT
details JSON                    -- Metadaten (z.B. Handoff-Details)
is_pinned TINYINT(1)           -- Wichtige Einträge (z.B. HANDOFF)
```

#### `telephony_call` (neu)

Für sipgate-Integration:

```sql
call_ref CHAR(36) PRIMARY KEY
work_item_uuid CHAR(36)
activity_id BIGINT             -- Referenz zu work_item_timeline
sipgate_call_id VARCHAR(255)
user_id VARCHAR(255)
phone_number VARCHAR(50)
state VARCHAR(50)              -- initiated | ringing | connected | ended | failed
duration INT                   -- Sekunden
error_message TEXT
last_polled_at DATETIME
```

#### `user_telephony_profile` (neu)

User-Device-Mapping für sipgate:

```sql
profile_id INT PRIMARY KEY
user_id VARCHAR(255) UNIQUE
sipgate_device_id VARCHAR(255) -- z.B. "e0"
is_active TINYINT(1)
```

---

## Workflow-Stages

### LEAD-Stages

- **NEW**: Neuer Lead, noch nicht bearbeitet
- **IN_PROGRESS**: Aktuell in Bearbeitung
- **SNOOZED**: Aufgeschoben (mit `next_action_at`)
- **QUALIFIED**: Qualifiziert, bereit für Übergabe
- **DISQUALIFIED**: Nicht qualifiziert
- **DUPLICATE**: Dublette
- **DATA_CHECK**: Unklare Datenlage, an Sales Ops übergeben (bleibt LEAD)

### VORGANG-Stages

- **QUOTE_REQUESTED**: Angebot angefordert (nach Qualifizierung)
- **QUOTING**: Angebot wird erstellt
- Weitere Stages folgen dem bestehenden VORGANG-Workflow

---

## API-Endpunkte

### WorkItems

#### `GET /api/work-items?type=LEAD&tab=new`
Listet WorkItems nach Typ und Tab.

**Tabs für LEAD:**
- `new`: Stage = NEW
- `due`: `next_action_at <= heute` oder NULL
- `in_progress`: Stage = IN_PROGRESS (optional: gefiltert nach User)
- `snoozed`: Stage = SNOOZED, `next_action_at > heute`
- `qualified`: Stage = QUALIFIED

**Tabs für VORGANG:**
- `team_queue`: Stage IN (QUOTE_REQUESTED, QUOTING), `owner_user_id IS NULL`
- `data_check`: Stage = DATA_CHECK, `owner_user_id IS NULL` (nur für LEAD)

**Sortierung:**
- Data Check: `stars DESC, updated_at DESC` (frisch übergeben zuerst)
- Angebote: `stars DESC, next_action_at ASC (NULL zuerst), created_at ASC` (ältere zuerst)
- Default: `stars DESC, next_action_at ASC (NULL zuerst), last_touch_at ASC`

#### `GET /api/work-items/:uuid`
Ruft ein einzelnes WorkItem ab.

#### `GET /api/work-items/:uuid/timeline`
Ruft die Timeline für ein WorkItem ab.

#### `PATCH /api/work-items/:uuid`
Aktualisiert WorkItem-Eigenschaften.

**Felder:**
- `priorityStars` / `priority_stars`
- `nextActionAt` / `next_action_at`
- `nextActionType` / `next_action_type`
- `stage`
- `ownerTeam` / `owner_team`
- `ownerUserId` / `owner_user_id`

**Return-Request (automatisch erkannt):**
```json
{
  "ownerTeam": "inside_sales",
  "ownerUserId": null,
  "stage": "NEW",
  "nextActionAt": "2026-01-05T10:00:00",
  "nextActionType": "call",
  "returnNotes": "Optional: Notiz zur Rückgabe"
}
```

#### `POST /api/work-items/:uuid/activities`
Fügt eine neue Activity zur Timeline hinzu.

**Types:**
- `NOTE`: Notiz
- `NEXT_ACTION_SET`: Wiedervorlage gesetzt

#### `POST /api/work-items/:uuid/handoff`
Übergibt ein LEAD an Sales Ops.

**Request:**
```json
{
  "handoffType": "QUOTE_REQUEST" | "DATA_CHECK",
  "stars": 4,
  "summary": {
    "needSummary": "Bedarf in 1 Satz",
    "contactHint": "Ansprechpartner/Abteilung",
    "nextStep": "Nächster Schritt"
  },
  "dataCheck": {
    "issue": "Was ist unklar?",
    "request": "Was soll geklärt werden?",
    "links": ["https://..."],
    "suspectedDuplicateCompanyId": null
  }
}
```

**Response:**
```json
{
  "workItem": { ... },
  "handoffActivityId": 9001
}
```

**Effekte:**
- **QUOTE_REQUEST**: `type → VORGANG`, `stage → QUOTE_REQUESTED`, `owner_team → sales_ops`
- **DATA_CHECK**: `stage → DATA_CHECK`, `owner_team → sales_ops` (bleibt LEAD)

#### `POST /api/work-items/:uuid/claim`
Übernimmt ein WorkItem (setzt `owner_user_id`).

#### `POST /api/work-items/:uuid/convert-to-vorgang`
**Veraltet:** Nutze `/handoff` mit `handoffType: "QUOTE_REQUEST"`.

### Queues

#### `POST /api/queues/inside-sales/next`
Ruft den nächsten verfügbaren Lead ab und weist ihn dem User zu.

**Response:**
```json
{
  "workItem": { ... } | null
}
```

### Telephony

#### `POST /api/telephony/calls`
Startet einen Anruf via sipgate.

**Request:**
```json
{
  "workItemUuid": "...",
  "phoneNumber": "+49..."
}
```

**Response:**
```json
{
  "callRef": "...",
  "activityId": 123,
  "sipgateCallId": "...",
  "state": "initiated"
}
```

#### `GET /api/telephony/calls/:callRef`
Ruft den aktuellen Status eines Anrufs ab.

**Response:**
```json
{
  "state": "ringing" | "connected" | "ended" | "failed",
  "duration": 120,
  "errorMessage": null
}
```

#### `POST /api/telephony/activities/:activityId/finalize`
Finalisiert eine Call-Activity.

**Request:**
```json
{
  "outcome": "connected" | "no_answer" | "voicemail" | "busy" | "failed",
  "notes": "Notizen zum Anruf",
  "nextActionAt": "2026-01-05T10:00:00",
  "nextActionType": "call"
}
```

---

## Frontend-Module

### Inside Sales Module (`public/js/modules/inside-sales.js`)

#### `initQueue(container)`
Rendert die Queue-Übersicht mit Tabs.

#### `initDialer(container)`
Rendert den Lead-Player (Dialer) mit:
- Mini-Queue (nächste Leads)
- Lead-Card (aktueller Lead)
- Outcome-Bar (Schnell-Buttons)
- Disposition-Sheet (Notizen, Wiedervorlage, Snooze)
- Timeline
- Call-Button (sipgate-Integration)

#### `loadNextLead()`
Lädt den nächsten Lead via `/api/queues/inside-sales/next`.

#### `saveDisposition()`
Speichert Disposition (Outcome, Notes, Next Action).

#### `submitHandover(handoffType)`
Übergibt Lead an Sales Ops (QUOTE_REQUEST oder DATA_CHECK).

#### `startCall()`
Startet Anruf via Telephony-API.

#### `startCallPolling(callRef, activityId)`
Pollt Call-Status und aktualisiert UI.

**Hotkeys:**
- `1-5`: Sterne setzen
- `S`: Save & Next
- `N`: Notizen-Feld fokussieren
- `Esc`: Disposition schließen

### Sales Ops Module (`public/js/modules/sales-ops.js`)

#### `initQueue(container)`
Rendert Sales Ops Queue mit zwei Tabs:
- **Angebote**: VORGANG, Stage IN (QUOTE_REQUESTED, QUOTING)
- **Data Check**: LEAD, Stage = DATA_CHECK

#### `loadQueue(tab)`
Lädt Queue nach Tab.

#### `renderWorkItemDetail(workItem)`
Zeigt WorkItem-Details mit Timeline.

#### `claimWorkItem(workItemUuid)`
Übernimmt WorkItem.

#### `returnToInsideSales()`
Gibt WorkItem zurück an Inside Sales (nur bei DATA_CHECK).

---

## Handoff-Beispiele

### 1. Inside Sales → Sales Ops: DATA_CHECK

**Request:**
```http
POST /api/work-items/123/handoff
Content-Type: application/json
X-CSRF-Token: ...

{
  "handoffType": "DATA_CHECK",
  "stars": 4,
  "summary": {
    "needSummary": "Akquise-Lead aus Import, Datenlage unklar – noch kein Bedarf bestätigt.",
    "contactHint": "Zentrale/Empfang; Ansprechpartner unbekannt",
    "nextStep": "Bitte Kontaktdaten/Nummer validieren, dann zurück an Inside Sales"
  },
  "dataCheck": {
    "issue": "Telefonnummer fehlt/ist ungültig; Website unklar; möglicher Dubletteintrag im Import.",
    "request": "Bitte Website/Domain recherchieren, Telefonnummer ergänzen, Dublette prüfen (Name/Ort/Adresse).",
    "links": ["https://www.handelsregister.de/"],
    "suspectedDuplicateCompanyId": null
  }
}
```

**Effekt:**
- `work_item`: bleibt LEAD, `stage → DATA_CHECK`, `owner_team → sales_ops`, `owner_user_id → NULL`
- `activity`: HANDOFF pinned, `details.handoffType = DATA_CHECK`

### 2. Inside Sales → Sales Ops: QUOTE_REQUEST

**Request:**
```http
POST /api/work-items/124/handoff
Content-Type: application/json
X-CSRF-Token: ...

{
  "handoffType": "QUOTE_REQUEST",
  "stars": 5,
  "summary": {
    "needSummary": "Kunde benötigt Angebot für Maschine X inkl. Montage; Bedarf bestätigt im Call.",
    "contactHint": "Herr Müller (Einkauf), Tel +49..., E-Mail mueller@...",
    "nextStep": "Angebot erstellen und per E-Mail senden; Rückfrage zur Lieferzeit offen"
  }
}
```

**Effekt:**
- `work_item`: `type → VORGANG`, `stage → QUOTE_REQUESTED`, `owner_team → sales_ops`, `owner_user_id → NULL`
- `activity`: HANDOFF pinned, `details.handoffType = QUOTE_REQUEST`

### 3. Sales Ops → Inside Sales: Return nach Data Check

**Request:**
```http
PATCH /api/work-items/123
Content-Type: application/json
X-CSRF-Token: ...

{
  "ownerTeam": "inside_sales",
  "ownerUserId": null,
  "stage": "NEW",
  "nextActionAt": "2026-01-05T10:00:00",
  "nextActionType": "call",
  "returnNotes": "Data Check erledigt – zurück an Inside Sales\n\nTelefonnummer ergänzt: +49 30 ...\nWebsite hinzugefügt: https://example.de\nDublette-Check: keine Dublette gefunden"
}
```

**Effekt:**
- `work_item`: `owner_team → inside_sales`, `stage → NEW`, `next_action_at` gesetzt
- `activity`: Optional STATUS_CHANGED mit `returnNotes`

---

## Queue-Definitionen

### Sales Ops Data Check Queue

**Filter:**
- `type = LEAD`
- `stage = DATA_CHECK`
- `status = 'neu'` (OPEN)
- `owner_team = 'sales_ops'`
- `owner_user_id IS NULL` (Team Queue)

**Sortierung:**
- `stars DESC` (höher zuerst)
- `updated_at DESC` (frisch übergeben zuerst)

**SQL-Beispiel:**
```sql
SELECT wi.*
FROM case_item wi
WHERE wi.case_type = 'LEAD'
  AND wi.stage = 'DATA_CHECK'
  AND wi.status = 'neu'
  AND wi.owner_team = 'sales_ops'
  AND wi.owner_user_id IS NULL
ORDER BY wi.priority_stars DESC, wi.updated_at DESC
LIMIT 100;
```

### Sales Ops Offer / Quote Requested Team Queue

**Filter:**
- `type = VORGANG`
- `stage IN ('QUOTE_REQUESTED', 'QUOTING')`
- `status = 'neu'` (OPEN)
- `owner_team = 'sales_ops'`
- `owner_user_id IS NULL` (Team Queue)

**Sortierung:**
- `stars DESC`
- `next_action_at ASC` (NULL zuerst)
- `created_at ASC` (ältere zuerst)

**SQL-Beispiel:**
```sql
SELECT wi.*
FROM case_item wi
WHERE wi.case_type = 'VORGANG'
  AND wi.stage IN ('QUOTE_REQUESTED', 'QUOTING')
  AND wi.status = 'neu'
  AND wi.owner_team = 'sales_ops'
  AND wi.owner_user_id IS NULL
ORDER BY wi.priority_stars DESC,
         CASE WHEN wi.next_action_at IS NULL THEN 0 ELSE 1 END,
         wi.next_action_at ASC,
         wi.created_at ASC
LIMIT 100;
```

---

## sipgate-Integration

### Konfiguration

**Environment-Variablen:**
```env
SIPGATE_API_URL=https://api.sipgate.com/v2
SIPGATE_TOKEN_ID=your_token_id
SIPGATE_TOKEN=your_token
```

**User-Profile anlegen:**
```sql
INSERT INTO user_telephony_profile (user_id, sipgate_device_id, is_active)
VALUES ('user@example.com', 'e0', 1);
```

### Ablauf

1. **Call starten:**
   - User klickt "Call"-Button im Dialer
   - Frontend ruft `POST /api/telephony/calls` auf
   - Backend erstellt `TOUCH_CALL` Activity
   - Backend ruft sipgate API auf
   - Response: `callRef`, `activityId`, `state: "initiated"`

2. **Status polling:**
   - Frontend startet Polling (alle 2 Sekunden)
   - `GET /api/telephony/calls/:callRef`
   - Backend cached Status (max. 5 Sekunden)
   - UI zeigt: "Ringing..." oder "Connected (00:45)"

3. **Call beendet:**
   - Status wird `ended` oder `failed`
   - Polling stoppt
   - Disposition-Sheet öffnet sich automatisch
   - User kann Outcome, Notes, Next Action eingeben

4. **Finalisieren:**
   - `POST /api/telephony/activities/:activityId/finalize`
   - Activity wird mit Outcome/Notes aktualisiert
   - Optional: `next_action_at` setzen

---

## Migrationen

### 055: Extend case_item for Inside Sales
```bash
source database/migrations/055_extend_case_item_for_inside_sales_mysql.sql
```

### 056: Create work_item_timeline
```bash
source database/migrations/056_create_work_item_timeline_mysql.sql
```

### 057: Create telephony tables
```bash
source database/migrations/057_create_telephony_tables_mysql.sql
```

---

## UI-Navigation

### Menü-Integration

**Inside Sales:**
- Menüpunkt unter "Dashboard" → "Inside Sales"
- Route: `#inside-sales` (Queue) oder `#inside-sales/dialer` (Dialer)

**Sales Ops:**
- Menüpunkt unter "Prozesse" → "Sales Ops"
- Route: `#sales-ops`

---

## Best Practices

### Inside Sales

1. **Lead-Player nutzen:** Für effiziente Bearbeitung
2. **Hotkeys verwenden:** Schnelleres Arbeiten
3. **Sterne setzen:** Priorisierung für Team
4. **Timeline pflegen:** Notizen für Nachvollziehbarkeit
5. **Snooze nutzen:** Systematische Wiedervorlage

### Sales Ops

1. **Data Check Queue prüfen:** Regelmäßig auf neue Leads
2. **Return-Notizen:** Detaillierte Rückgabe-Notizen für Inside Sales
3. **Claim nutzen:** Persönliche Übernahme für bessere Übersicht
4. **Timeline lesen:** Handoff-Details in Timeline prüfen

### Allgemein

1. **WorkItem als Single Source of Truth:** Alle Infos im WorkItem
2. **Timeline für Historie:** Alle Aktivitäten dokumentieren
3. **Klare Handoffs:** Strukturierte Übergabe mit Metadaten
4. **Progressive Komplexität:** Nur einführen, was nötig ist

---

## Troubleshooting

### Problem: Lead erscheint nicht in Queue

**Prüfen:**
- `case_type = 'LEAD'`?
- `stage` passt zum Tab?
- `status = 'neu'`?
- `owner_team` korrekt?

### Problem: Call startet nicht

**Prüfen:**
- sipgate Credentials in ENV?
- User-Profile in DB vorhanden?
- `sipgate_device_id` korrekt?
- Telefonnummer-Format (+49...)?

### Problem: Timeline zeigt keine Einträge

**Prüfen:**
- `work_item_uuid` korrekt?
- Activities wurden erstellt?
- Timeline-Service funktioniert?

---

## Changelog

### Version 1.0 (2026-01-05)
- ✅ Kapitel 1: WorkItem + Timeline (Foundation)
- ✅ Kapitel 2: Lead-Player + Disposition-Flow
- ✅ Kapitel 3: Qualify & Handoff (LEAD → VORGANG)
- ✅ Kapitel 4: sipgate Webphone-Integration

---

## Weitere Ressourcen

- **Code-Referenzen:**
  - `src/TOM/Service/WorkItemService.php`
  - `src/TOM/Service/WorkItemTimelineService.php`
  - `src/TOM/Service/TelephonyService.php`
  - `public/api/work-items.php`
  - `public/api/queues.php`
  - `public/api/telephony.php`
  - `public/js/modules/inside-sales.js`
  - `public/js/modules/sales-ops.js`

- **Datenbank-Migrationen:**
  - `database/migrations/055_extend_case_item_for_inside_sales_mysql.sql`
  - `database/migrations/056_create_work_item_timeline_mysql.sql`
  - `database/migrations/057_create_telephony_tables_mysql.sql`

